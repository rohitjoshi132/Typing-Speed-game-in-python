import tkinter as tk
from tkinter import messagebox
import time
import sqlite3
from essential_generators import DocumentGenerator
import random
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# --- Database Setup ---
conn = sqlite3.connect("typing_game.db")
cur = conn.cursor()

cur.execute('''CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT)''')

cur.execute('''CREATE TABLE IF NOT EXISTS scores(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                wpm INTEGER,
                accuracy REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id))''')
conn.commit()

# --- Function to start game ---
def start_game(username, user_id):
    game_root = tk.Tk()
    TypingSpeedGame(game_root, username, user_id)
    game_root.mainloop()

# --- Login/Register Window ---
class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Login - Typing Speed Game")
        self.root.geometry("400x350")
        self.root.config(bg="#0f172a")

        tk.Label(root, text="Typing Speed Test Login", font=("Helvetica", 18, "bold"),
                 fg="#22d3ee", bg="#0f172a").pack(pady=20)

        tk.Label(root, text="Username:", font=("Helvetica", 14), fg="white", bg="#0f172a").pack()
        self.username_entry = tk.Entry(root, font=("Helvetica", 14), bg="#1e293b", fg="white", insertbackground="white")
        self.username_entry.pack(pady=10)

        tk.Label(root, text="Password:", font=("Helvetica", 14), fg="white", bg="#0f172a").pack()
        self.password_entry = tk.Entry(root, font=("Helvetica", 14), bg="#1e293b", fg="white", insertbackground="white", show="*")
        self.password_entry.pack(pady=10)

        self.login_btn = tk.Button(root, text="Login", font=("Helvetica", 14),
                                   bg="#2563eb", fg="white", activebackground="#1e40af", command=self.login)
        self.login_btn.pack(pady=5)

        self.register_btn = tk.Button(root, text="Register", font=("Helvetica", 14),
                                      bg="#16a34a", fg="white", activebackground="#15803d", command=self.register)
        self.register_btn.pack(pady=5)

    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if not username or not password:
            messagebox.showwarning("Input Error", "Please enter both username and password.")
            return
        cur.execute("SELECT id FROM users WHERE username=? AND password=?", (username, password))
        user = cur.fetchone()
        if user:
            self.root.destroy()
            start_game(username, user[0])
        else:
            messagebox.showerror("Login Failed", "Invalid username or password. Please register first.")

    def register(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if not username or not password:
            messagebox.showwarning("Input Error", "Please enter both username and password.")
            return
        try:
            cur.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            cur.execute("SELECT id FROM users WHERE username=?", (username,))
            user = cur.fetchone()
            messagebox.showinfo("Success", f"Welcome {username}! Account created successfully.")
            self.root.destroy()
            start_game(username, user[0])
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username already exists. Try logging in.")

# --- Typing Speed Game ---
class TypingSpeedGame:
    MOTIVATIONAL_QUOTES = [
        "Keep pushing your limits!",
        "Practice makes perfect!",
        "Every keystroke counts!",
        "Consistency is the key to mastery!",
        "Great job! Keep going!",
        "Small progress is still progress!",
        "You are getting better every day!",
        "Accuracy and speed will improve with practice!"
    ]

    def __init__(self, root, username, user_id):
        self.root = root
        self.username = username
        self.user_id = user_id

        self.root.title("Typing Speed Test Game")
        self.root.geometry("950x600")
        self.root.minsize(800, 550)
        self.root.config(bg="#0f172a")

        self.dark_theme = {
            "bg": "#0f172a",
            "fg": "#f8fafc",
            "btn_bg": "#2563eb",
            "btn_fg": "white",
            "timer_fg": "#facc15",
            "accent": "#22d3ee",
            "entry_bg": "#1e293b",
            "entry_fg": "white"
        }
        self.current_theme = self.dark_theme

        self.gen = DocumentGenerator()
        self.time_left = 30
        self.start_time = None
        self.current_sentence = ""
        self.timer_running = False

        # --- UI Elements ---
        self.label_title = tk.Label(root, text=f"💡 Welcome, {self.username}!", font=("Helvetica", 26, "bold"),
                                    fg=self.current_theme["accent"], bg=self.current_theme["bg"])
        self.label_timer = tk.Label(root, text=f"Time: {self.time_left}s", font=("Helvetica", 20),
                                    fg=self.current_theme["timer_fg"], bg=self.current_theme["bg"])
        self.label_sentence = tk.Label(root, text="", wraplength=850, font=("Helvetica", 18),
                                       fg=self.current_theme["accent"], bg=self.current_theme["bg"])
        self.entry = tk.Entry(root, font=("Helvetica", 16), width=60,
                              bg=self.current_theme["entry_bg"], fg=self.current_theme["entry_fg"], insertbackground="white")
        self.entry.bind("<KeyPress>", self.start_timer)
        self.entry.bind("<Return>", lambda event: self.end_test())

        self.btn_restart = tk.Button(root, text="Start New Test", font=("Helvetica", 14),
                                     bg=self.current_theme["btn_bg"], fg=self.current_theme["btn_fg"], activebackground="#1e40af",
                                     command=self.new_test)

        self.result_label = tk.Label(root, text="", font=("Helvetica", 16),
                                     fg=self.current_theme["fg"], bg=self.current_theme["bg"])

        self.profile_icon = tk.Button(root, text="👤", font=("Helvetica", 24), bg=self.current_theme["bg"],
                                      fg="white", bd=0, activebackground=self.current_theme["bg"], command=self.show_profile_popup)

        # --- Layout ---
        self.label_title.place(relx=0.5, rely=0.05, anchor="center")
        self.label_timer.place(relx=0.05, rely=0.05, anchor="nw")
        self.label_sentence.place(relx=0.5, rely=0.2, anchor="center")
        self.entry.place(relx=0.5, rely=0.35, anchor="center")
        self.btn_restart.place(relx=0.5, rely=0.5, anchor="center")
        self.result_label.place(relx=0.5, rely=0.65, anchor="center")
        self.profile_icon.place(relx=0.95, rely=0.05, anchor="ne")

        self.new_test()

    def new_test(self):
        self.entry.config(state="normal")
        self.entry.delete(0, tk.END)
        self.time_left = 30
        self.current_sentence = self.gen.sentence()
        self.label_sentence.config(text=self.current_sentence)
        self.result_label.config(text="")
        self.label_timer.config(text=f"Time: {self.time_left}s")
        self.timer_running = False
        self.start_time = None

    def start_timer(self, event):
        if not self.timer_running:
            self.start_time = time.time()
            self.timer_running = True
            self.countdown()

    def countdown(self):
        if not self.timer_running:
            return
        if self.time_left > 0:
            self.time_left -= 1
            self.label_timer.config(text=f"Time: {self.time_left}s")
            self.root.after(1000, self.countdown)
        else:
            self.end_test()

    def end_test(self):
        if not self.timer_running:
            return
        self.timer_running = False
        self.entry.config(state="disabled")

        typed_text = self.entry.get()
        words_typed = len(typed_text.split())
        elapsed = max(time.time() - self.start_time, 1)
        wpm = round(words_typed / (elapsed / 60))
        correct = sum(1 for a, b in zip(typed_text, self.current_sentence) if a == b)
        accuracy = (correct / max(len(self.current_sentence), 1)) * 100

        self.result_label.config(text=f"✅ WPM: {wpm} | Accuracy: {accuracy:.1f}%")

        quote = random.choice(self.MOTIVATIONAL_QUOTES)
        motivational_label = tk.Label(self.root, text=f"💡 {quote}", font=("Helvetica", 14, "italic"),
                                      fg="#facc15", bg=self.current_theme["bg"])
        motivational_label.place(relx=0.5, rely=0.72, anchor="center")

        cur.execute("INSERT INTO scores (user_id, wpm, accuracy) VALUES (?, ?, ?)",
                    (self.user_id, wpm, accuracy))
        conn.commit()

    # --- Scrollable Profile Popup ---
    def show_profile_popup(self):
        popup = tk.Toplevel(self.root)
        popup.title("User Profile")
        popup.geometry("450x600")
        popup.config(bg=self.current_theme["bg"])

        container = tk.Frame(popup, bg=self.current_theme["bg"])
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(container, bg=self.current_theme["bg"])
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.current_theme["bg"])

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # --- User Info ---
        cur.execute("SELECT MAX(wpm), AVG(accuracy), COUNT(*) FROM scores WHERE user_id = ?", (self.user_id,))
        high, avg, count = cur.fetchone() or (0, 0, 0)

        tk.Label(scrollable_frame, text=f"👤 {self.username}", font=("Helvetica", 20, "bold"),
                 fg=self.current_theme["accent"], bg=self.current_theme["bg"]).pack(pady=10)
        tk.Label(scrollable_frame, text=f"Best WPM: {int(high) if high else 0}", font=("Helvetica", 14),
                 fg=self.current_theme["fg"], bg=self.current_theme["bg"]).pack(pady=5)
        tk.Label(scrollable_frame, text=f"Average Accuracy: {avg:.1f}%" if avg else "Average Accuracy: 0%", font=("Helvetica", 14),
                 fg=self.current_theme["fg"], bg=self.current_theme["bg"]).pack(pady=5)
        tk.Label(scrollable_frame, text=f"Tests Taken: {count}", font=("Helvetica", 14),
                 fg=self.current_theme["fg"], bg=self.current_theme["bg"]).pack(pady=5)

        # --- Top 3 Results ---
        tk.Label(scrollable_frame, text="🏆 Top 3 Results:", font=("Helvetica", 16, "bold"),
                 fg="#facc15", bg=self.current_theme["bg"]).pack(pady=10)

        cur.execute("SELECT wpm, accuracy, timestamp FROM scores WHERE user_id = ? ORDER BY wpm DESC LIMIT 3",
                    (self.user_id,))
        top_scores = cur.fetchall()

        if top_scores:
            for idx, (wpm, acc, time_) in enumerate(top_scores, start=1):
                tk.Label(scrollable_frame,
                         text=f"{idx}. {wpm} WPM | {acc:.1f}% | {time_[:10]}",
                         font=("Helvetica", 13),
                         fg=self.current_theme["fg"], bg=self.current_theme["bg"]).pack(pady=3)
        else:
            tk.Label(scrollable_frame, text="No scores yet!", font=("Helvetica", 13, "italic"),
                     fg="#94a3b8", bg=self.current_theme["bg"]).pack(pady=5)

        # --- Graph ---
        graph_frame = tk.Frame(scrollable_frame, bg=self.current_theme["bg"])
        graph_frame.pack(pady=10)

        cur.execute("SELECT timestamp, wpm, accuracy FROM scores WHERE user_id = ? ORDER BY timestamp", (self.user_id,))
        data = cur.fetchall()
        if data:
            timestamps = [row[0][:10] for row in data]
            wpm_values = [row[1] for row in data]
            acc_values = [row[2] for row in data]

            fig, ax = plt.subplots(figsize=(4.2, 3))
            ax.plot(timestamps, wpm_values, marker='o', label='WPM', color='#22d3ee')
            ax.plot(timestamps, acc_values, marker='x', label='Accuracy %', color='#facc15')
            ax.set_title("Typing Performance Over Time")
            ax.set_xlabel("Date")
            ax.set_ylabel("Value")
            ax.legend()
            ax.grid(True)
            fig.tight_layout()
            plt.xticks(rotation=45)

            canvas_graph = FigureCanvasTkAgg(fig, master=graph_frame)
            canvas_graph.draw()
            canvas_graph.get_tk_widget().pack()

        # --- Buttons ---
        button_frame = tk.Frame(scrollable_frame, bg=self.current_theme["bg"])
        button_frame.pack(pady=15)

        tk.Button(button_frame, text="View History", font=("Helvetica", 12),
                  bg=self.current_theme["btn_bg"], fg=self.current_theme["btn_fg"],
                  command=self.show_history).pack(side="left", padx=10)
        tk.Button(button_frame, text="Close", font=("Helvetica", 12),
                  bg=self.current_theme["btn_bg"], fg=self.current_theme["btn_fg"],
                  command=popup.destroy).pack(side="right", padx=10)

    # --- Show History ---
    def show_history(self):
        hist_popup = tk.Toplevel(self.root)
        hist_popup.title("Typing History")
        hist_popup.geometry("450x500")
        hist_popup.config(bg=self.current_theme["bg"])

        container = tk.Frame(hist_popup, bg=self.current_theme["bg"])
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(container, bg=self.current_theme["bg"])
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.current_theme["bg"])

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        cur.execute("SELECT wpm, accuracy, timestamp FROM scores WHERE user_id=? ORDER BY timestamp DESC", (self.user_id,))
        data = cur.fetchall()
        if data:
            for idx, (wpm, acc, time_) in enumerate(data, start=1):
                tk.Label(scrollable_frame,
                         text=f"{idx}. {wpm} WPM | {acc:.1f}% | {time_[:10]}",
                         font=("Helvetica", 13),
                         fg=self.current_theme["fg"], bg=self.current_theme["bg"]).pack(pady=3)
        else:
            tk.Label(scrollable_frame, text="No history yet!", font=("Helvetica", 13, "italic"),
                     fg="#94a3b8", bg=self.current_theme["bg"]).pack(pady=5)

# --- Run Program ---
if __name__ == "__main__":
    root = tk.Tk()
    LoginWindow(root)
    root.mainloop()
